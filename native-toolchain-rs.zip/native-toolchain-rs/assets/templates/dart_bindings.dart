import 'dart:ffi';
import 'package:ffi/ffi.dart';

import 'native_types.dart';
import 'ffi_utils.dart';

/// FFI Bindings for {{PACKAGE_NAME}}
///
/// This file contains the Dart bindings to the Rust FFI functions.
/// Using @Native annotation (Dart 3.0+) for cleaner, more maintainable bindings.

// CRITICAL: Asset ID format is 'package:<package_name>/<asset_name>'
// The asset_name must match:
// - Cargo.toml package name
// - RustBuilder assetName in hook/build.dart
const String _assetId = 'package:{{PACKAGE_NAME}}/{{ASSET_NAME}}';

// Error handling functions

/// Get the last error message from the native library
/// Returns null if no error occurred
/// MUST call freeErrorString() on the result to avoid memory leaks
@Native<Pointer<Utf8> Function()>(
  symbol: 'get_last_error',
  assetId: _assetId,
)
external Pointer<Utf8> getLastError();

/// Free an error string allocated by the native library
@Native<Void Function(Pointer<Utf8>)>(
  symbol: 'free_error_string',
  assetId: _assetId,
)
external void freeErrorString(Pointer<Utf8> ptr);

// Handle management functions

/// Create a new handle with the given name
/// Returns a pointer to the handle, or nullptr on error
/// MUST call destroyHandle() when done to avoid memory leaks
@Native<Pointer<ExampleHandle> Function(Pointer<Utf8>)>(
  symbol: 'create_handle',
  assetId: _assetId,
)
external Pointer<ExampleHandle> createHandle(Pointer<Utf8> name);

/// Destroy a handle and free its memory
@Native<Void Function(Pointer<ExampleHandle>)>(
  symbol: 'destroy_handle',
  assetId: _assetId,
)
external void destroyHandle(Pointer<ExampleHandle> handle);

/// Perform an operation on a handle
/// Returns 0 on success, negative error code on failure
@Native<Int32 Function(Pointer<ExampleHandle>)>(
  symbol: 'handle_operation',
  assetId: _assetId,
)
external int handleOperation(Pointer<ExampleHandle> handle);

/// Get data from a handle
/// Returns a string that MUST be freed with freeErrorString()
@Native<Pointer<Utf8> Function(Pointer<ExampleHandle>)>(
  symbol: 'get_data',
  assetId: _assetId,
)
external Pointer<Utf8> getData(Pointer<ExampleHandle> handle);

// High-level Dart wrapper class

/// High-level Dart wrapper for the native handle
/// Provides automatic memory management via finalizers
class ExampleWrapper {
  final Pointer<ExampleHandle> _handle;

  /// Create a new wrapper with the given name
  /// Throws an exception if creation fails
  ExampleWrapper(String name) : _handle = _createHandle(name) {
    // Attach finalizer for automatic cleanup when garbage collected
    _finalizer.attach(this, _handle, detach: this);
  }

  /// Manually dispose of the handle
  /// Call this when done to free resources immediately
  /// After calling dispose(), this object should not be used
  void dispose() {
    _finalizer.detach(this);
    destroyHandle(_handle);
  }

  /// Perform an operation on the handle
  /// Throws an exception if the operation fails
  void performOperation() {
    final result = handleOperation(_handle);
    if (result != 0) {
      throw _getError() ?? 'Operation failed with code $result';
    }
  }

  /// Get data from the handle
  /// Throws an exception if retrieval fails
  String fetchData() {
    final dataPtr = getData(_handle);
    if (dataPtr == nullptr) {
      throw _getError() ?? 'Failed to get data';
    }

    try {
      return cStringToDartString(dataPtr);
    } finally {
      freeErrorString(dataPtr);
    }
  }

  // Private helper methods

  static Pointer<ExampleHandle> _createHandle(String name) {
    final namePtr = stringToCString(name);
    try {
      final handle = createHandle(namePtr);
      if (handle == nullptr) {
        throw _getError() ?? 'Failed to create handle';
      }
      return handle;
    } finally {
      freeCString(namePtr);
    }
  }

  static String? _getError() {
    final errorPtr = getLastError();
    if (errorPtr == nullptr) {
      return null;
    }

    try {
      return cStringToDartString(errorPtr);
    } finally {
      freeErrorString(errorPtr);
    }
  }

  // Finalizer for automatic cleanup when object is garbage collected
  static final _finalizer = NativeFinalizer(
    Native.addressOf<Void Function(Pointer<ExampleHandle>)>(destroyHandle),
  );
}
