import 'dart:ffi';
import 'package:ffi/ffi.dart';

/// Utility functions for safe FFI operations
///
/// These functions help with common FFI tasks like string conversion
/// and memory management, reducing boilerplate and preventing memory leaks.

/// Convert a Dart String to a C string (UTF-8 encoded)
/// The caller MUST free the returned pointer using freeCString()
///
/// Example:
/// ```dart
/// final ptr = stringToCString('hello');
/// try {
///   nativeFunction(ptr);
/// } finally {
///   freeCString(ptr);
/// }
/// ```
Pointer<Utf8> stringToCString(String str) {
  return str.toNativeUtf8(allocator: malloc);
}

/// Convert a C string to a Dart String
/// Throws ArgumentError if the pointer is null
///
/// Example:
/// ```dart
/// final dartString = cStringToDartString(cStringPtr);
/// ```
String cStringToDartString(Pointer<Utf8> ptr) {
  if (ptr == nullptr) {
    throw ArgumentError.notNull('ptr');
  }
  return ptr.toDartString();
}

/// Free a C string allocated by stringToCString()
/// Safe to call with nullptr
///
/// Example:
/// ```dart
/// final ptr = stringToCString('hello');
/// try {
///   nativeFunction(ptr);
/// } finally {
///   freeCString(ptr);
/// }
/// ```
void freeCString(Pointer<Utf8> ptr) {
  if (ptr != nullptr) {
    malloc.free(ptr);
  }
}

/// Check if a pointer is null and throw if it is
/// Useful for validating pointers before use
void ensureNotNull(Pointer ptr, String paramName) {
  if (ptr == nullptr) {
    throw ArgumentError.notNull(paramName);
  }
}

/// Helper function to safely call a native function with string arguments
/// Automatically handles memory allocation and cleanup
///
/// Example:
/// ```dart
/// final result = withCString('hello', (ptr) {
///   return nativeFunction(ptr);
/// });
/// ```
T withCString<T>(String str, T Function(Pointer<Utf8>) callback) {
  final ptr = stringToCString(str);
  try {
    return callback(ptr);
  } finally {
    freeCString(ptr);
  }
}

/// Helper function to safely call a native function with multiple string arguments
/// Automatically handles memory allocation and cleanup
///
/// Example:
/// ```dart
/// final result = withCStrings(['hello', 'world'], (ptrs) {
///   return nativeFunction(ptrs[0], ptrs[1]);
/// });
/// ```
T withCStrings<T>(List<String> strings, T Function(List<Pointer<Utf8>>) callback) {
  final ptrs = strings.map(stringToCString).toList();
  try {
    return callback(ptrs);
  } finally {
    for (final ptr in ptrs) {
      freeCString(ptr);
    }
  }
}
