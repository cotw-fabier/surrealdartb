import 'dart:ffi';

/// Opaque native types for FFI
///
/// These types represent native handles that cannot be directly accessed from Dart.
/// They are only used as pointers (Pointer<Type>) and their internal structure
/// is managed entirely by the native (Rust) code.

/// Example opaque handle type
/// Corresponds to the ExampleHandle struct in Rust
final class ExampleHandle extends Opaque {}

// Add more opaque types as needed for your FFI bindings
// Example:
// final class DatabaseHandle extends Opaque {}
// final class ConnectionHandle extends Opaque {}
// final class QueryHandle extends Opaque {}
