import 'package:hooks/hooks.dart';
import 'package:native_toolchain_rs/native_toolchain_rs.dart';

/// Native Assets build hook for Rust FFI bindings
///
/// This hook runs automatically during build to compile the Rust library
/// for all target platforms. No manual cargo build commands needed!
void main(List<String> args) async {
  await build(args, (input, output) async {
    await RustBuilder(
      // CRITICAL: assetName must match the package name in Cargo.toml
      assetName: '{{ASSET_NAME}}',

      // Optional: Enable specific Cargo features
      // cargoFeatures: ['feature1', 'feature2'],

      // Optional: Specify custom Rust workspace location (default: rust/ or native/)
      // rustWorkspace: 'path/to/rust/workspace',
    ).run(input: input, output: output);
  });
}
