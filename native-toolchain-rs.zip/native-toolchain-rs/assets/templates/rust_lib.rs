use std::ffi::{CStr, CString};
use std::os::raw::c_char;
use std::panic;
use std::cell::RefCell;

/// Thread-local storage for error messages
/// This pattern allows FFI functions to return error codes while preserving error details
thread_local! {
    static LAST_ERROR: RefCell<Option<String>> = RefCell::new(None);
}

/// Store an error message in thread-local storage
pub fn set_last_error(error: &str) {
    LAST_ERROR.with(|e| *e.borrow_mut() = Some(error.to_string()));
}

/// Retrieve the last error message from thread-local storage
/// Returns a C string that the caller must free using free_error_string()
#[no_mangle]
pub extern "C" fn get_last_error() -> *mut c_char {
    LAST_ERROR.with(|e| {
        match e.borrow_mut().take() {
            Some(err) => CString::new(err).unwrap().into_raw(),
            None => std::ptr::null_mut(),
        }
    })
}

/// Free a C string allocated by Rust
/// CRITICAL: Must be called by Dart to free error strings returned by get_last_error()
#[no_mangle]
pub extern "C" fn free_error_string(ptr: *mut c_char) {
    if !ptr.is_null() {
        unsafe {
            // Reconstruct the CString and drop it to free memory
            drop(CString::from_raw(ptr));
        }
    }
}

/// Example opaque handle type
/// This pattern allows passing complex Rust types across FFI boundary safely
pub struct ExampleHandle {
    pub data: String,
    // Add your fields here
}

/// Create a new handle
/// Returns a raw pointer that Dart must eventually pass to destroy_handle()
#[no_mangle]
pub extern "C" fn create_handle(name: *const c_char) -> *mut ExampleHandle {
    // Wrap in panic::catch_unwind to prevent panics from crossing FFI boundary
    match panic::catch_unwind(|| {
        // Validate input
        if name.is_null() {
            set_last_error("name cannot be null");
            return std::ptr::null_mut();
        }

        // Convert C string to Rust string
        let name_str = unsafe {
            match CStr::from_ptr(name).to_str() {
                Ok(s) => s,
                Err(_) => {
                    set_last_error("Invalid UTF-8 in name");
                    return std::ptr::null_mut();
                }
            }
        };

        // Create the handle and transfer ownership to caller
        let handle = Box::new(ExampleHandle {
            data: name_str.to_string(),
        });

        Box::into_raw(handle)
    }) {
        Ok(result) => result,
        Err(_) => {
            set_last_error("Panic occurred in create_handle");
            std::ptr::null_mut()
        }
    }
}

/// Destroy a handle and free its memory
/// CRITICAL: Must be called by Dart when done with the handle to prevent memory leaks
#[no_mangle]
pub extern "C" fn destroy_handle(handle: *mut ExampleHandle) {
    if !handle.is_null() {
        unsafe {
            // Reconstruct the Box and drop it to free memory
            drop(Box::from_raw(handle));
        }
    }
}

/// Example operation on a handle
/// Returns 0 on success, negative error code on failure
#[no_mangle]
pub extern "C" fn handle_operation(handle: *mut ExampleHandle) -> i32 {
    match panic::catch_unwind(|| {
        // Validate handle
        if handle.is_null() {
            set_last_error("Handle cannot be null");
            return -1;
        }

        // Access the handle safely
        let handle_ref = unsafe { &mut *handle };

        // Perform operation
        handle_ref.data.push_str(" - modified");

        // Return success
        0
    }) {
        Ok(result) => result,
        Err(_) => {
            set_last_error("Panic occurred in handle_operation");
            -1
        }
    }
}

/// Example function that returns a string
/// Returns a C string that the caller must free using free_error_string()
#[no_mangle]
pub extern "C" fn get_data(handle: *mut ExampleHandle) -> *mut c_char {
    match panic::catch_unwind(|| {
        if handle.is_null() {
            set_last_error("Handle cannot be null");
            return std::ptr::null_mut();
        }

        let handle_ref = unsafe { &*handle };

        match CString::new(handle_ref.data.clone()) {
            Ok(c_string) => c_string.into_raw(),
            Err(_) => {
                set_last_error("Failed to convert string");
                std::ptr::null_mut()
            }
        }
    }) {
        Ok(result) => result,
        Err(_) => {
            set_last_error("Panic occurred in get_data");
            std::ptr::null_mut()
        }
    }
}

// Optional: Add tests
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_handle_creation() {
        let name = CString::new("test").unwrap();
        let handle = create_handle(name.as_ptr());
        assert!(!handle.is_null());
        destroy_handle(handle);
    }

    #[test]
    fn test_error_handling() {
        let handle = create_handle(std::ptr::null());
        assert!(handle.is_null());

        let error = get_last_error();
        assert!(!error.is_null());
        free_error_string(error);
    }
}
