# Platform-Specific Considerations

This document covers platform-specific details, requirements, and best practices when using native_toolchain_rs across different operating systems and environments.

## General Principles

### Library Format by Platform

| Platform | File Extension | Type | Location |
|----------|---------------|------|----------|
| macOS | `.dylib` | Dynamic | `lib/` or system |
| iOS | `.a` | Static | Embedded in app |
| Android | `.so` | Dynamic | APK `lib/` dirs |
| Linux | `.so` | Dynamic | `lib/` or system |
| Windows | `.dll` | Dynamic | Executable dir |

### Why Both `staticlib` and `cdylib`?

Always specify both in `Cargo.toml`:

```toml
[lib]
crate-type = ["staticlib", "cdylib"]
```

**Reason:**
- **`staticlib`**: Required for iOS (no dynamic linking allowed on iOS)
- **`cdylib`**: Required for all other platforms (smaller, allows code sharing)

Native_toolchain_rs automatically selects the appropriate format for each platform.

## macOS

### Target Architectures

```toml
[toolchain]
targets = [
  "aarch64-apple-darwin",  # Apple Silicon (M1/M2/M3)
  "x86_64-apple-darwin",   # Intel Macs
]
```

### Requirements

- **Xcode Command Line Tools:** Required for compilation
  ```bash
  xcode-select --install
  ```

- **Minimum OS Version:** Set in Cargo.toml if needed:
  ```toml
  [profile.release]
  rustflags = ["-C", "link-arg=-mmacosx-version-min=10.15"]
  ```

### Universal Binaries

Native_toolchain_rs automatically creates universal (fat) binaries containing both architectures when both targets are installed:

```bash
# Install both targets
rustup target add aarch64-apple-darwin x86_64-apple-darwin

# Build will create universal binary automatically
dart run --enable-experiment=native-assets
```

### Sandboxing

macOS apps may be sandboxed. Ensure your FFI code:
- Doesn't access files outside the sandbox container
- Uses proper entitlements for network access if needed
- Doesn't spawn unauthorized processes

### Code Signing

For distribution, your native library needs to be signed:

```bash
# Sign the library
codesign --sign "Developer ID Application: Your Name" \
  --timestamp \
  --options runtime \
  rust/target/release/libmy_bindings.dylib

# Verify signature
codesign --verify --verbose rust/target/release/libmy_bindings.dylib
```

For notarization:
```bash
# Create a zip for notarization
ditto -c -k --keepParent rust/target/release/libmy_bindings.dylib my_bindings.zip

# Submit for notarization
xcrun notarytool submit my_bindings.zip \
  --apple-id your@email.com \
  --team-id TEAMID \
  --password app-specific-password
```

## iOS

### Target Architectures

```toml
[toolchain]
targets = [
  "aarch64-apple-ios",      # Physical devices (iPhone, iPad)
  "x86_64-apple-ios",       # Simulator on Intel Macs
  "aarch64-apple-ios-sim",  # Simulator on Apple Silicon Macs
]
```

### Requirements

- **Xcode** (full version, not just Command Line Tools)
- **iOS SDK** (included with Xcode)
- **Valid Apple Developer account** (for device testing)

### iOS-Specific Limitations

**1. No Dynamic Linking:**
iOS doesn't support dynamic libraries for third-party code. Native_toolchain_rs automatically uses static linking (`.a` files).

**2. Bitcode:**
As of Xcode 14, bitcode is no longer required or supported. You can remove any bitcode-related flags.

**3. App Store Requirements:**
- All architectures must be included in submission
- No private APIs (usually not an issue with FFI)
- Clear description of what native code does

### Testing

**Simulator:**
```bash
# Build for simulator
flutter build ios --simulator --enable-experiment=native-assets

# Run on simulator
flutter run --enable-experiment=native-assets
```

**Physical Device:**
```bash
# Build for device (requires signing)
flutter build ios --enable-experiment=native-assets

# Run on connected device
flutter run -d <device-id> --enable-experiment=native-assets
```

### Size Optimization

iOS apps have size limits. Optimize Rust library:

```toml
[profile.release]
opt-level = "z"  # Optimize for size
lto = true
codegen-units = 1
strip = true
panic = "abort"  # Smaller panic handling
```

Additional size reduction:
```toml
[profile.release]
# Remove debug symbols
strip = "symbols"

# Exclude unused code
panic = "abort"
overflow-checks = false
```

## Android

### Target Architectures

```toml
[toolchain]
targets = [
  "aarch64-linux-android",    # 64-bit ARM (vast majority of devices)
  "armv7-linux-androideabi",  # 32-bit ARM (older devices)
  "x86_64-linux-android",     # 64-bit x86 (emulators)
  "i686-linux-android",       # 32-bit x86 (rare)
]
```

**Recommendation:** At minimum, support `aarch64-linux-android`. This covers 90%+ of modern devices.

### Requirements

**1. Android NDK:**
```bash
# Install via Android Studio SDK Manager
# Or via command line:
sdkmanager --install "ndk;25.2.9519653"  # Use latest version

# Set environment variable
export ANDROID_NDK_HOME=$HOME/Library/Android/sdk/ndk/25.2.9519653
```

**2. Minimum API Level:**
Set in `android/app/build.gradle`:
```gradle
android {
    defaultConfig {
        minSdkVersion 21  # Android 5.0 minimum for modern Rust
    }
}
```

For Rust 1.68+, minimum API 21 is required.

### ABI Splits

To reduce APK size, create separate APKs per architecture:

**android/app/build.gradle:**
```gradle
android {
    splits {
        abi {
            enable true
            reset()
            include 'arm64-v8a', 'armeabi-v7a', 'x86_64'
            universalApk false
        }
    }
}
```

This creates separate APKs:
- `app-arm64-v8a-release.apk` (aarch64-linux-android)
- `app-armeabi-v7a-release.apk` (armv7-linux-androideabi)
- `app-x86_64-release.apk` (x86_64-linux-android)

Google Play automatically serves the correct APK per device.

### ProGuard/R8

If using code shrinking, ensure native methods aren't removed:

**android/app/proguard-rules.pro:**
```
# Keep native methods
-keepclasseswithmembers class * {
    native <methods>;
}

# Keep classes that use FFI
-keep class your.package.ffi.** { *; }
```

### JNI Considerations

While native_toolchain_rs handles the build, be aware:
- Flutter's FFI doesn't use JNI directly
- Native libraries are loaded via `System.loadLibrary()`
- No need to write JNI wrappers

### Testing

**Emulator:**
```bash
# Create emulator if needed
flutter emulators

# Run on emulator
flutter run --enable-experiment=native-assets
```

**Physical Device:**
```bash
# Enable USB debugging on device
adb devices

# Run on device
flutter run -d <device-id> --enable-experiment=native-assets
```

**Inspect APK:**
```bash
# Build APK
flutter build apk --enable-experiment=native-assets

# List contents
unzip -l build/app/outputs/flutter-apk/app-release.apk | grep "\.so"

# Should show:
# lib/arm64-v8a/libmy_bindings.so
# lib/armeabi-v7a/libmy_bindings.so
# etc.
```

## Linux

### Target Architectures

```toml
[toolchain]
targets = [
  "x86_64-unknown-linux-gnu",    # 64-bit x86 (most common)
  "aarch64-unknown-linux-gnu",   # 64-bit ARM (Raspberry Pi, AWS Graviton)
  "x86_64-unknown-linux-musl",   # Static linking (optional)
]
```

### Requirements

**Debian/Ubuntu:**
```bash
sudo apt-get update
sudo apt-get install build-essential pkg-config
```

**Fedora/RHEL:**
```bash
sudo dnf install gcc make
```

**Arch:**
```bash
sudo pacman -S base-devel
```

### GLIBC Compatibility

Rust links against GLIBC by default. For maximum compatibility:

**Option 1: Target older GLIBC:**
Build on an older Linux distribution (e.g., Ubuntu 20.04 for wider compatibility).

**Option 2: Use MUSL for static linking:**
```toml
[toolchain]
targets = ["x86_64-unknown-linux-musl"]
```

```bash
# Install MUSL target
rustup target add x86_64-unknown-linux-musl

# May need to install musl-tools
sudo apt-get install musl-tools
```

Benefits:
- Fully static binary (no GLIBC dependency)
- Maximum portability

Drawbacks:
- Slightly larger binary
- Some crates don't support MUSL

### Library Search Path

Linux looks for `.so` files in specific locations:
1. Directories in `LD_LIBRARY_PATH`
2. Directories in `/etc/ld.so.conf`
3. `/lib`, `/lib64`, `/usr/lib`, `/usr/lib64`

Native_toolchain_rs bundles the library with your app, so this usually isn't an issue.

If issues occur:
```bash
# Check library dependencies
ldd rust/target/release/libmy_bindings.so

# Run with explicit library path
LD_LIBRARY_PATH=rust/target/release dart run your_app.dart
```

### Snap/Flatpak Considerations

If distributing via Snap or Flatpak:
- Library must be included in the snap/flatpak
- May need additional permissions for FFI
- Test thoroughly in confined environment

## Windows

### Target Architectures

```toml
[toolchain]
targets = [
  "x86_64-pc-windows-msvc",  # 64-bit Windows (most common)
  "i686-pc-windows-msvc",    # 32-bit Windows (rare)
  "x86_64-pc-windows-gnu",   # MinGW (alternative)
]
```

**Recommendation:** Use `x86_64-pc-windows-msvc` (MSVC toolchain) for best compatibility and performance.

### Requirements

**Option 1: Visual Studio (Recommended)**
- Install Visual Studio 2019 or later
- Include "Desktop development with C++" workload
- Or install "Build Tools for Visual Studio"

**Option 2: MinGW (Alternative)**
- Install MinGW-w64
- Less common, may have compatibility issues

### Runtime Dependencies

Applications built with MSVC target require Visual C++ Redistributables:

**Check if installed:**
```powershell
Get-ItemProperty HKLM:\SOFTWARE\Microsoft\VisualStudio\*\VC\Runtimes\x64
```

**Distribute with app:**
- Include `vcredist_x64.exe` installer
- Or ship the required DLLs with your app (check licensing)

**Required DLLs** (if shipping):
- `msvcp140.dll`
- `vcruntime140.dll`
- `vcruntime140_1.dll` (sometimes)

### Path and Encoding

Windows has some quirks:

**1. Path Separators:**
```rust
// Handle both separators
let path = path.replace("\\", "/");
```

**2. File Paths:**
```rust
// Use canonical paths
let path = std::fs::canonicalize(path)?;
```

**3. UTF-16:**
Windows uses UTF-16 for wide strings. For FFI with Dart, stick to UTF-8:
```rust
// Dart sends UTF-8, which works fine with c_char
let s = CStr::from_ptr(ptr).to_str()?;
```

### DLL Loading

Windows looks for DLLs in this order:
1. Application directory
2. System directory (`C:\Windows\System32`)
3. Windows directory (`C:\Windows`)
4. Current directory
5. Directories in `PATH`

Native_toolchain_rs places the DLL in the application directory, so it's found first.

### Debugging Windows-Specific Issues

**Check DLL dependencies:**
```powershell
# Install Dependencies.exe from https://github.com/lucasg/Dependencies
Dependencies.exe rust\target\release\my_bindings.dll
```

**Check exports:**
```powershell
dumpbin /EXPORTS rust\target\release\my_bindings.dll
```

**Run with error details:**
```powershell
$env:RUST_BACKTRACE=1
dart run your_app.dart
```

## Web (WASM)

### Current Status

As of Dart 3.x, native_toolchain_rs **does not support web targets**. FFI is not available in web builds.

### Alternatives for Web

**1. Compile Rust to WASM separately:**
```toml
[lib]
crate-type = ["cdylib"]

[dependencies]
wasm-bindgen = "0.2"
```

```bash
wasm-pack build --target web
```

Then use `dart:js_interop` to call WASM functions.

**2. Conditional compilation:**
```dart
import 'package:flutter/foundation.dart' show kIsWeb;

void initNativeLibrary() {
  if (kIsWeb) {
    // Use WASM or pure Dart implementation
    print('Running on web, native FFI not available');
  } else {
    // Use FFI
    initFFI();
  }
}
```

**3. Pure Dart fallback:**
Implement critical functionality in pure Dart as fallback:
```dart
abstract class Database {
  factory Database() {
    if (kIsWeb) {
      return DatabaseDartImpl();  // Pure Dart
    } else {
      return DatabaseFFIImpl();   // Rust FFI
    }
  }
}
```

## Cross-Compilation Tips

### Build for Multiple Platforms

```bash
# Install all targets
rustup target add \
  aarch64-apple-darwin x86_64-apple-darwin \
  aarch64-apple-ios x86_64-apple-ios aarch64-apple-ios-sim \
  aarch64-linux-android armv7-linux-androideabi \
  x86_64-unknown-linux-gnu \
  x86_64-pc-windows-msvc

# Native_toolchain_rs builds all needed targets automatically
dart run --enable-experiment=native-assets
```

### GitHub Actions CI

Example workflow for multi-platform builds:

```yaml
name: Build Native Libraries

on: [push, pull_request]

jobs:
  build:
    strategy:
      matrix:
        os: [ubuntu-latest, macos-latest, windows-latest]

    runs-on: ${{ matrix.os }}

    steps:
      - uses: actions/checkout@v3

      - name: Setup Rust
        uses: actions-rs/toolchain@v1
        with:
          toolchain: 1.90.0
          override: true

      - name: Setup Dart
        uses: dart-lang/setup-dart@v1

      - name: Install targets
        run: rustup show  # Installs from rust-toolchain.toml

      - name: Install dependencies
        run: dart pub get

      - name: Build
        run: dart run --enable-experiment=native-assets

      - name: Test
        run: dart test --enable-experiment=native-assets
```

### Docker for Reproducible Builds

**Dockerfile:**
```dockerfile
FROM ubuntu:22.04

# Install dependencies
RUN apt-get update && apt-get install -y \
    curl \
    git \
    build-essential \
    && rm -rf /var/lib/apt/lists/*

# Install Rust
RUN curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
ENV PATH="/root/.cargo/bin:${PATH}"

# Install Dart
RUN curl -fsSL https://dl-ssl.google.com/linux/linux_signing_key.pub | apt-key add -
RUN curl -fsSL https://storage.googleapis.com/download.dartlang.org/linux/debian/dart_stable.list > /etc/apt/sources.list.d/dart_stable.list
RUN apt-get update && apt-get install -y dart

WORKDIR /app

# Copy and build
COPY . .
RUN dart pub get
RUN dart run --enable-experiment=native-assets
```

Build:
```bash
docker build -t my_app_builder .
docker run --rm -v $(pwd)/build:/app/build my_app_builder
```

## Performance Characteristics by Platform

### FFI Call Overhead

Approximate overhead per FFI call (varies by hardware):

| Platform | Overhead | Notes |
|----------|----------|-------|
| macOS | ~10-20ns | Very fast |
| iOS | ~10-20ns | Similar to macOS |
| Android | ~20-50ns | Slightly slower |
| Linux | ~10-30ns | Depends on distro |
| Windows | ~30-60ns | MSVC has overhead |

**Recommendation:** Batch operations when possible to amortize overhead.

### Memory Performance

| Platform | Allocation Speed | Notes |
|----------|------------------|-------|
| All | Fast | Rust's allocator is efficient on all platforms |

**Recommendation:** Reuse allocations when possible, especially for strings passed across FFI.

### Build Times

Approximate clean build times for medium-sized project:

| Platform | Time | Notes |
|----------|------|-------|
| macOS | 2-5 min | Fast, especially on Apple Silicon |
| Linux | 2-5 min | Fast with good CPU |
| Windows | 5-10 min | Slower, MSVC overhead |

**Tip:** Use `sccache` to cache Rust compilations:
```bash
cargo install sccache
export RUSTC_WRAPPER=sccache
```
