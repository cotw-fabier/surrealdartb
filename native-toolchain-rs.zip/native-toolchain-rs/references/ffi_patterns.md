# FFI Patterns and Best Practices

This document provides detailed patterns for implementing safe and effective FFI (Foreign Function Interface) between Rust and Dart using native_toolchain_rs.

## Core Principles

### FFI Safety Contract

**Rust Side Guarantees:**
- Never panic across FFI boundary (always use `panic::catch_unwind`)
- Return simple integer error codes (0 = success, negative = error)
- Store detailed error messages in thread-local storage
- Validate all inputs before use (null checks, bounds checks)
- Use opaque handles for complex types (never expose internal structures)

**Dart Side Responsibilities:**
- Free all allocated memory (strings, handles) using provided destructors
- Attach finalizers to resource wrappers for automatic cleanup
- Never expose raw Pointer types in public APIs
- Validate inputs before passing to native code
- Handle all exceptions gracefully

## Rust Patterns

### 1. Error Handling Pattern

Always use thread-local storage for error messages:

```rust
use std::cell::RefCell;

thread_local! {
    static LAST_ERROR: RefCell<Option<String>> = RefCell::new(None);
}

pub fn set_last_error(error: &str) {
    LAST_ERROR.with(|e| *e.borrow_mut() = Some(error.to_string()));
}

#[no_mangle]
pub extern "C" fn get_last_error() -> *mut c_char {
    LAST_ERROR.with(|e| {
        match e.borrow_mut().take() {
            Some(err) => CString::new(err).unwrap().into_raw(),
            None => std::ptr::null_mut(),
        }
    })
}

#[no_mangle]
pub extern "C" fn free_error_string(ptr: *mut c_char) {
    if !ptr.is_null() {
        unsafe { drop(CString::from_raw(ptr)); }
    }
}
```

**Why this pattern:**
- Simple integer return codes are FFI-safe
- Detailed error messages available when needed
- Thread-safe (each thread has its own error)
- No memory leaks (errors are taken, not cloned)

### 2. FFI Function Structure

Every FFI function should follow this template:

```rust
#[no_mangle]
pub extern "C" fn function_name(arg: *const c_char) -> i32 {
    // Step 1: Wrap everything in panic::catch_unwind
    match panic::catch_unwind(|| {
        // Step 2: Validate inputs
        if arg.is_null() {
            set_last_error("Argument cannot be null");
            return -1;
        }

        // Step 3: Convert C types to Rust types
        let rust_str = unsafe {
            match CStr::from_ptr(arg).to_str() {
                Ok(s) => s,
                Err(_) => {
                    set_last_error("Invalid UTF-8 in argument");
                    return -2;
                }
            }
        };

        // Step 4: Perform the operation
        match perform_operation(rust_str) {
            Ok(_) => 0,  // Success
            Err(e) => {
                set_last_error(&e.to_string());
                -3  // Operation failed
            }
        }
    }) {
        Ok(result) => result,
        Err(_) => {
            set_last_error("Panic occurred in function_name");
            -999  // Panic code
        }
    }
}
```

**Error code conventions:**
- `0` = Success
- `-1` = Invalid input (null, invalid format, etc.)
- `-2` = Conversion error (UTF-8, type conversion, etc.)
- `-3 to -99` = Domain-specific errors
- `-999` = Panic occurred

### 3. Opaque Handle Pattern

For complex types that need to cross the FFI boundary:

```rust
// Opaque type - internal structure hidden from Dart
pub struct DatabaseHandle {
    connection: Connection,
    config: Config,
    // ... internal fields
}

// Create (transfer ownership to Dart)
#[no_mangle]
pub extern "C" fn create_database(config_json: *const c_char) -> *mut DatabaseHandle {
    match panic::catch_unwind(|| {
        // Validate and parse config
        // ...

        let handle = Box::new(DatabaseHandle {
            connection: establish_connection(),
            config: parsed_config,
        });

        Box::into_raw(handle)  // Transfer ownership
    }) {
        Ok(result) => result,
        Err(_) => {
            set_last_error("Panic in create_database");
            std::ptr::null_mut()
        }
    }
}

// Operate on handle (Dart still owns it)
#[no_mangle]
pub extern "C" fn database_query(handle: *mut DatabaseHandle, query: *const c_char) -> i32 {
    match panic::catch_unwind(|| {
        if handle.is_null() {
            set_last_error("Handle cannot be null");
            return -1;
        }

        let db = unsafe { &mut *handle };
        // Perform query using db...

        0
    }) {
        Ok(result) => result,
        Err(_) => {
            set_last_error("Panic in database_query");
            -999
        }
    }
}

// Destroy (transfer ownership back to Rust)
#[no_mangle]
pub extern "C" fn destroy_database(handle: *mut DatabaseHandle) {
    if !handle.is_null() {
        unsafe {
            drop(Box::from_raw(handle));  // Reclaim and drop
        }
    }
}
```

**Memory ownership:**
- Create: Rust allocates, transfers to Dart (via `Box::into_raw`)
- Operate: Dart owns, Rust borrows temporarily (via `&mut *handle`)
- Destroy: Dart transfers back, Rust drops (via `Box::from_raw`)

### 4. String Return Pattern

When returning strings from Rust:

```rust
#[no_mangle]
pub extern "C" fn get_string_value(handle: *mut Handle) -> *mut c_char {
    match panic::catch_unwind(|| {
        if handle.is_null() {
            set_last_error("Handle cannot be null");
            return std::ptr::null_mut();
        }

        let handle_ref = unsafe { &*handle };
        let result_string = get_value_from_handle(handle_ref);

        match CString::new(result_string) {
            Ok(c_string) => c_string.into_raw(),
            Err(_) => {
                set_last_error("String contains null byte");
                std::ptr::null_mut()
            }
        }
    }) {
        Ok(result) => result,
        Err(_) => {
            set_last_error("Panic in get_string_value");
            std::ptr::null_mut()
        }
    }
}
```

**Important:**
- Caller (Dart) must free the returned string
- Always check for null bytes before creating CString
- Use the same free function as error strings

### 5. Async Operations Pattern

For async Rust code in synchronous FFI:

```rust
use tokio::runtime::Runtime;

// Create runtime once, store in handle or static
static RUNTIME: Lazy<Runtime> = Lazy::new(|| {
    Runtime::new().expect("Failed to create Tokio runtime")
});

#[no_mangle]
pub extern "C" fn async_operation(handle: *mut Handle) -> i32 {
    match panic::catch_unwind(|| {
        if handle.is_null() {
            set_last_error("Handle cannot be null");
            return -1;
        }

        let handle_ref = unsafe { &mut *handle };

        // Bridge async to sync using block_on
        match RUNTIME.block_on(async_function(handle_ref)) {
            Ok(_) => 0,
            Err(e) => {
                set_last_error(&e.to_string());
                -3
            }
        }
    }) {
        Ok(result) => result,
        Err(_) => {
            set_last_error("Panic in async_operation");
            -999
        }
    }
}
```

**Important:**
- FFI is always synchronous from Dart's perspective
- Use `block_on` to wait for async operations
- Consider using Dart's async/await and Isolates for true concurrency

## Dart Patterns

### 1. Native Function Binding

Use the `@Native` annotation (Dart 3.0+):

```dart
@Native<Int32 Function(Pointer<Utf8>)>(
  symbol: 'native_function_name',
  assetId: 'package:your_package/your_asset',
)
external int nativeFunction(Pointer<Utf8> arg);
```

**Key points:**
- `symbol`: exact name of Rust function (from `#[no_mangle]`)
- `assetId`: format is `package:<package_name>/<asset_name>`
- Asset name must match Cargo.toml package name
- Use exact C types in signature (Int32, Pointer, Void, etc.)

### 2. High-Level Wrapper Pattern

Always wrap low-level FFI in safe Dart classes:

```dart
class Database {
  final Pointer<DatabaseHandle> _handle;

  Database(String configJson) : _handle = _create(configJson) {
    // Attach finalizer for automatic cleanup
    _finalizer.attach(this, _handle, detach: this);
  }

  // Manual dispose for immediate cleanup
  void dispose() {
    _finalizer.detach(this);
    destroyDatabase(_handle);
  }

  // High-level methods hide FFI details
  Future<List<Map<String, dynamic>>> query(String sql) async {
    return await Isolate.run(() {
      final sqlPtr = stringToCString(sql);
      try {
        final result = databaseQuery(_handle, sqlPtr);
        if (result != 0) {
          throw _getError() ?? 'Query failed';
        }
        // Parse and return results...
      } finally {
        freeCString(sqlPtr);
      }
    });
  }

  static Pointer<DatabaseHandle> _create(String config) {
    final configPtr = stringToCString(config);
    try {
      final handle = createDatabase(configPtr);
      if (handle == nullptr) {
        throw _getError() ?? 'Failed to create database';
      }
      return handle;
    } finally {
      freeCString(configPtr);
    }
  }

  static String? _getError() {
    final errorPtr = getLastError();
    if (errorPtr == nullptr) return null;
    try {
      return cStringToDartString(errorPtr);
    } finally {
      freeErrorString(errorPtr);
    }
  }

  static final _finalizer = NativeFinalizer(
    Native.addressOf<Void Function(Pointer<DatabaseHandle>)>(destroyDatabase),
  );
}
```

**Benefits:**
- Users never see `Pointer` types
- Automatic memory management
- Idiomatic Dart async/await
- Exception-based error handling

### 3. Error Checking Pattern

Always check error codes and retrieve error messages:

```dart
void checkError(int errorCode, [String? context]) {
  if (errorCode == 0) return;  // Success

  String message = context ?? 'Operation failed';

  final errorPtr = getLastError();
  if (errorPtr != nullptr) {
    try {
      message = '$message: ${cStringToDartString(errorPtr)}';
    } finally {
      freeErrorString(errorPtr);
    }
  }

  switch (errorCode) {
    case -1:
      throw ArgumentError(message);
    case -2:
      throw FormatException(message);
    case -3:
      throw StateError(message);
    case -999:
      throw StateError('Native panic: $message');
    default:
      throw Exception('$message (code: $errorCode)');
  }
}

// Usage:
final result = nativeOperation(handle);
checkError(result, 'Failed to perform operation');
```

### 4. Resource Management Pattern

Always use try-finally for temporary allocations:

```dart
// Single string
final ptr = stringToCString('value');
try {
  nativeFunction(ptr);
} finally {
  freeCString(ptr);
}

// Multiple strings
final ptrs = ['a', 'b', 'c'].map(stringToCString).toList();
try {
  nativeFunction(ptrs[0], ptrs[1], ptrs[2]);
} finally {
  ptrs.forEach(freeCString);
}

// Or use helper functions
withCString('value', (ptr) => nativeFunction(ptr));

withCStrings(['a', 'b', 'c'], (ptrs) {
  return nativeFunction(ptrs[0], ptrs[1], ptrs[2]);
});
```

### 5. Finalizer Pattern

Use `NativeFinalizer` for automatic cleanup:

```dart
class ResourceWrapper {
  final Pointer<NativeHandle> _handle;

  ResourceWrapper(this._handle) {
    // Attach this object to the finalizer
    // When object is GC'd, finalizer calls the destructor
    _finalizer.attach(
      this,           // The Dart object to watch
      _handle,        // The value passed to the finalizer callback
      detach: this,   // Token for manual detachment
    );
  }

  void dispose() {
    // Manual cleanup - detach first to prevent double-free
    _finalizer.detach(this);
    nativeDestroyHandle(_handle);
  }

  // Create finalizer ONCE as static
  static final _finalizer = NativeFinalizer(
    // Get function pointer for the native destructor
    Native.addressOf<Void Function(Pointer<NativeHandle>)>(
      nativeDestroyHandle
    ),
  );
}
```

**Important:**
- Create finalizer once as `static final`
- Always provide `detach` token for manual disposal
- Call `detach()` before manual cleanup to prevent double-free
- Finalizers run asynchronously - don't rely on timing

## Common Patterns by Use Case

### Database Connection

**Rust:**
```rust
pub struct DbHandle {
    conn: Connection,
}

#[no_mangle]
pub extern "C" fn db_connect(url: *const c_char) -> *mut DbHandle { /* ... */ }

#[no_mangle]
pub extern "C" fn db_query(handle: *mut DbHandle, sql: *const c_char, result_json: *mut *mut c_char) -> i32 { /* ... */ }

#[no_mangle]
pub extern "C" fn db_disconnect(handle: *mut DbHandle) { /* ... */ }
```

**Dart:**
```dart
class Database {
  final Pointer<DbHandle> _handle;
  Database(String url) : _handle = _connect(url);
  Future<List<Map>> query(String sql) async => Isolate.run(() { /* ... */ });
  void close() => dbDisconnect(_handle);
}
```

### File Processing

**Rust:**
```rust
pub struct FileHandle { /* ... */ }

#[no_mangle]
pub extern "C" fn file_open(path: *const c_char, mode: *const c_char) -> *mut FileHandle { /* ... */ }

#[no_mangle]
pub extern "C" fn file_read(handle: *mut FileHandle, buffer: *mut u8, size: usize) -> i64 { /* ... */ }

#[no_mangle]
pub extern "C" fn file_close(handle: *mut FileHandle) { /* ... */ }
```

**Dart:**
```dart
class NativeFile {
  final Pointer<FileHandle> _handle;
  NativeFile.open(String path, String mode) : _handle = _open(path, mode);
  Uint8List read(int size) { /* ... */ }
  void close() => fileClose(_handle);
}
```

### Callback Pattern (Advanced)

When Dart needs to call Rust, which then calls back to Dart:

**Rust:**
```rust
type DartCallback = extern "C" fn(*const c_char);

#[no_mangle]
pub extern "C" fn process_with_callback(
    data: *const c_char,
    callback: DartCallback
) -> i32 {
    // Process data...
    // Call back to Dart
    let message = CString::new("Processing...").unwrap();
    callback(message.as_ptr());
    0
}
```

**Dart:**
```dart
@Native<Void Function(Pointer<Utf8>)>()
void callbackFunction(Pointer<Utf8> message) {
  print('Callback: ${cStringToDartString(message)}');
}

@Native<Int32 Function(Pointer<Utf8>, Pointer<NativeFunction<Void Function(Pointer<Utf8>)>>)>(
  symbol: 'process_with_callback',
  assetId: _assetId,
)
external int processWithCallback(
  Pointer<Utf8> data,
  Pointer<NativeFunction<Void Function(Pointer<Utf8>)>> callback,
);

// Usage:
final data = stringToCString('data');
try {
  final result = processWithCallback(
    data,
    Native.addressOf(callbackFunction),
  );
  checkError(result);
} finally {
  freeCString(data);
}
```

**Warning:** Callbacks add complexity and can cause lifetime issues. Use sparingly.
