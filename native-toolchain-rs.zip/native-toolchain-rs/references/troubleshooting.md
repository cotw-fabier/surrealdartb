# Troubleshooting Guide

Common issues when working with native_toolchain_rs and their solutions.

## Build Errors

### "error: can't find crate for `std`"

**Symptom:**
```
error[E0463]: can't find crate for `std`
  |
  = note: the `<target>` target may not be installed
```

**Cause:** Missing Rust target toolchain.

**Solution:**
```bash
rustup target add <target-name>

# Example: Add all common targets
rustup target add aarch64-apple-darwin x86_64-apple-darwin
rustup target add aarch64-apple-ios
rustup target add aarch64-linux-android armv7-linux-androideabi
rustup target add x86_64-unknown-linux-gnu aarch64-unknown-linux-gnu
rustup target add x86_64-pc-windows-msvc
```

Or add targets to `rust-toolchain.toml`:
```toml
[toolchain]
channel = "1.90.0"
targets = ["aarch64-apple-darwin", "x86_64-apple-darwin", ...]
```

Then run:
```bash
rustup show  # Installs targets from rust-toolchain.toml
```

### "error: invalid channel name: 'stable'"

**Symptom:**
```
error: invalid channel name: 'stable'
```

**Cause:** Using bare channel name like "stable" in `rust-toolchain.toml`.

**Solution:** Replace with specific version:
```toml
[toolchain]
# Wrong:
# channel = "stable"

# Correct:
channel = "1.90.0"
```

Check current stable version:
```bash
rustup check
# or
rustc --version
```

### "error: linking with `cc` failed"

**Symptom:**
```
error: linking with `cc` failed: exit code: 1
note: ld: library not found for -lSystem
```

**Cause:** Missing platform-specific linker or SDK.

**Solution:**

**macOS/iOS:**
```bash
# Install Xcode Command Line Tools
xcode-select --install

# Verify installation
xcode-select -p
```

**Android:**
- Install Android NDK via Android Studio
- Set `ANDROID_NDK_HOME` environment variable:
```bash
export ANDROID_NDK_HOME=$HOME/Library/Android/sdk/ndk/<version>
```

**Linux:**
```bash
# Ubuntu/Debian
sudo apt-get install build-essential

# Fedora/RHEL
sudo dnf install gcc
```

**Windows:**
- Install Visual Studio with C++ development tools
- Or install Build Tools for Visual Studio

### "crate-type must include both staticlib and cdylib"

**Symptom:**
Build fails or library not found on some platforms.

**Cause:** Missing required crate types in `Cargo.toml`.

**Solution:** Always specify BOTH:
```toml
[lib]
crate-type = ["staticlib", "cdylib"]
```

**Why both?**
- `staticlib`: Required for iOS (static linking)
- `cdylib`: Required for Android, macOS, Windows, Linux (dynamic linking)

### "Asset not found: package:my_package/my_asset"

**Symptom:**
```
Error: Asset not found: package:my_package/my_asset
```

**Cause:** Mismatch between asset names in different configuration files.

**Solution:** Ensure consistency across all three locations:

1. **Cargo.toml:**
```toml
[package]
name = "my_bindings"  # This is your asset name
```

2. **hook/build.dart:**
```dart
RustBuilder(
  assetName: 'my_bindings',  # Must match Cargo.toml name
)
```

3. **Dart bindings:**
```dart
const String _assetId = 'package:my_package/my_bindings';
//                              ^^^^^^^^^^  ^^^^^^^^^^^
//                              package     asset from
//                              name from   Cargo.toml
//                              pubspec
```

### "Directory native/ or rust/ not found"

**Symptom:**
```
Error: Could not find Rust workspace at native/ or rust/
```

**Cause:** Rust code not in expected location.

**Solution:**

**Option 1 (Recommended):** Move Rust code to standard location:
```bash
mkdir rust
mv my_rust_code/* rust/
```

**Option 2:** Specify custom location in `hook/build.dart`:
```dart
RustBuilder(
  assetName: 'my_bindings',
  rustWorkspace: 'path/to/rust/workspace',
)
```

## Runtime Errors

### "Symbol not found" or "undefined symbol"

**Symptom:**
```dart
Error: Symbol 'my_function' not found
```

**Cause:** Function not exported or name mangled.

**Solution:**

1. **Verify `#[no_mangle]` and `extern "C"`:**
```rust
#[no_mangle]  // REQUIRED
pub extern "C" fn my_function() -> i32 {
    // ...
}
```

2. **Check symbol is present:**
```bash
# macOS/Linux
nm rust/target/release/libmy_bindings.a | grep my_function

# Windows
dumpbin /SYMBOLS rust\target\release\my_bindings.lib | findstr my_function
```

3. **Verify symbol name in Dart matches:**
```dart
@Native<Int32 Function()>(
  symbol: 'my_function',  // Must match exactly
  assetId: 'package:my_package/my_bindings',
)
external int myFunction();
```

### Segmentation Fault / Access Violation

**Symptom:**
App crashes with segfault or access violation.

**Common causes and solutions:**

**1. Null pointer dereference:**
```rust
// Wrong:
let data = unsafe { &*ptr };  // If ptr is null, instant crash

// Correct:
if ptr.is_null() {
    set_last_error("Pointer cannot be null");
    return -1;
}
let data = unsafe { &*ptr };
```

**2. Use-after-free:**
```dart
// Wrong:
final handle = createHandle();
destroyHandle(handle);
useHandle(handle);  // CRASH: handle already freed

// Correct:
final handle = createHandle();
try {
  useHandle(handle);
} finally {
  destroyHandle(handle);
}
```

**3. Double-free:**
```dart
// Wrong:
class Wrapper {
  final ptr = createHandle();
  void dispose() {
    destroyHandle(ptr);
  }
  // Finalizer also calls destroyHandle(ptr)
}

// Correct:
class Wrapper {
  final ptr = createHandle();
  Wrapper() {
    _finalizer.attach(this, ptr, detach: this);
  }
  void dispose() {
    _finalizer.detach(this);  // Prevent finalizer from running
    destroyHandle(ptr);
  }
}
```

**4. Buffer overflow:**
```rust
// Wrong:
let buffer = vec![0u8; 10];
unsafe {
    std::ptr::copy(src, buffer.as_mut_ptr(), 100);  // Copies 100 bytes into 10-byte buffer
}

// Correct:
let buffer = vec![0u8; 100];
unsafe {
    std::ptr::copy(src, buffer.as_mut_ptr(), 100);
}
```

**5. Invalid UTF-8:**
```rust
// Wrong:
let s = unsafe { CStr::from_ptr(ptr).to_str().unwrap() };  // Can panic on invalid UTF-8

// Correct:
let s = unsafe {
    match CStr::from_ptr(ptr).to_str() {
        Ok(s) => s,
        Err(_) => {
            set_last_error("Invalid UTF-8");
            return -1;
        }
    }
};
```

### Memory Leaks

**Symptom:**
Memory usage grows over time and never decreases.

**Common causes and solutions:**

**1. Not freeing strings:**
```dart
// Wrong:
final str = nativeGetString(handle);
print(cStringToDartString(str));
// str never freed - LEAK

// Correct:
final str = nativeGetString(handle);
try {
  print(cStringToDartString(str));
} finally {
  freeString(str);
}
```

**2. Not destroying handles:**
```dart
// Wrong:
void doWork() {
  final handle = createHandle();
  performOperation(handle);
  // handle never destroyed - LEAK
}

// Correct:
void doWork() {
  final handle = createHandle();
  try {
    performOperation(handle);
  } finally {
    destroyHandle(handle);
  }
}

// Or use finalizers:
class Wrapper {
  final _handle = createHandle();
  Wrapper() {
    _finalizer.attach(this, _handle, detach: this);
  }
}
```

**3. Rust side not dropping:**
```rust
// Wrong:
#[no_mangle]
pub extern "C" fn create_handle() -> *mut Handle {
    let handle = Box::new(Handle { data: vec![/* large data */] });
    Box::into_raw(handle)
    // If destroy_handle is never called, this leaks
}

// Ensure you always provide and document a destructor:
#[no_mangle]
pub extern "C" fn destroy_handle(handle: *mut Handle) {
    if !handle.is_null() {
        unsafe { drop(Box::from_raw(handle)); }
    }
}
```

### "Bad state: No element" or Unexpected Null

**Symptom:**
```dart
Bad state: No element
// or
Null check operator used on a null value
```

**Cause:** Trying to access data that doesn't exist or hasn't been initialized.

**Solution:**

**1. Check return values:**
```dart
// Wrong:
final handle = createHandle(name);
performOperation(handle);  // Crash if createHandle returned null

// Correct:
final handle = createHandle(name);
if (handle == nullptr) {
  final error = getLastError();
  // Handle error...
  throw Exception('Failed to create handle');
}
performOperation(handle);
```

**2. Check error codes:**
```dart
// Wrong:
final result = performOperation(handle);
// Assume it worked

// Correct:
final result = performOperation(handle);
if (result != 0) {
  final error = getLastError();
  throw Exception('Operation failed: $error');
}
```

## Configuration Issues

### Native Assets experiment not enabled

**Symptom:**
```
Error: Native assets are not enabled
```

**Solution:**
```bash
# Dart
dart run --enable-experiment=native-assets

# Flutter
flutter run --enable-experiment=native-assets
```

Or add to `analysis_options.yaml` (not recommended for production):
```yaml
analyzer:
  enable-experiment:
    - native-assets
```

### Build hook not running

**Symptom:**
Native library not being built or updated.

**Solution:**

**1. Verify hook location:**
```
your_project/
├── hook/           # Must be named 'hook', not 'hooks'
│   └── build.dart  # Must be named 'build.dart'
```

**2. Verify hook/build.dart has correct imports:**
```dart
import 'package:hooks/hooks.dart';  // Required
import 'package:native_toolchain_rs/native_toolchain_rs.dart';  // Required
```

**3. Clean and rebuild:**
```bash
# Dart
dart clean
dart run --enable-experiment=native-assets

# Flutter
flutter clean
flutter run --enable-experiment=native-assets
```

### Wrong library loaded

**Symptom:**
Old version of native library being used despite changes.

**Solution:**

**1. Clean build artifacts:**
```bash
# Clean Dart build
dart clean

# Clean Rust build
cd rust
cargo clean
cd ..

# Rebuild
dart run --enable-experiment=native-assets
```

**2. Verify build artifacts:**
```bash
# Check Dart build directory
ls -la .dart_tool/native_assets/

# Check Rust build directory
ls -la rust/target/
```

## Platform-Specific Issues

### iOS: "Building for iOS, but the linked library is for macOS"

**Symptom:**
Build error when running on iOS device or simulator.

**Solution:**

Ensure `rust-toolchain.toml` includes iOS targets:
```toml
targets = [
  "aarch64-apple-ios",      # iOS devices
  "x86_64-apple-ios",       # iOS simulator (Intel)
  "aarch64-apple-ios-sim",  # iOS simulator (Apple Silicon)
]
```

### Android: "No implementation found for nativeMethod"

**Symptom:**
```
java.lang.UnsatisfiedLinkError: No implementation found for nativeMethod
```

**Solution:**

**1. Verify Android targets:**
```toml
targets = [
  "aarch64-linux-android",    # ARM64 (most common)
  "armv7-linux-androideabi",  # ARM32
  "x86_64-linux-android",     # x86_64 (emulator)
]
```

**2. Check NDK is installed:**
```bash
echo $ANDROID_NDK_HOME
# Should output something like: /Users/you/Library/Android/sdk/ndk/25.2.9519653
```

**3. Verify library is included in APK:**
```bash
# Build APK
flutter build apk

# Inspect APK contents
unzip -l build/app/outputs/flutter-apk/app-release.apk | grep libmy_bindings
```

### Windows: "The specified module could not be found"

**Symptom:**
```
Error: The specified module could not be found.
```

**Solution:**

**1. Verify Visual C++ Redistributables are installed:**
Download and install from Microsoft's website.

**2. Check dependencies:**
```bash
# Use Dependencies.exe (Dependency Walker alternative)
# Download from: https://github.com/lucasg/Dependencies
Dependencies.exe rust\target\release\my_bindings.dll
```

**3. Ensure correct target:**
```toml
[toolchain]
targets = ["x86_64-pc-windows-msvc"]  # Not "gnu"
```

## Performance Issues

### Slow FFI calls

**Symptom:**
FFI calls take longer than expected.

**Solutions:**

**1. Reduce string conversions:**
```dart
// Slow: Converts string on every call
for (var i = 0; i < 1000; i++) {
  final ptr = stringToCString('constant');
  nativeCall(ptr);
  freeCString(ptr);
}

// Fast: Convert once
final ptr = stringToCString('constant');
try {
  for (var i = 0; i < 1000; i++) {
    nativeCall(ptr);
  }
} finally {
  freeCString(ptr);
}
```

**2. Batch operations:**
```dart
// Slow: 1000 FFI calls
for (var item in items) {
  nativeProcess(item);
}

// Fast: 1 FFI call with batch
final batch = items.join(',');
nativeProcessBatch(batch);
```

**3. Use Isolates for heavy work:**
```dart
// Blocks UI
final result = expensiveNativeOperation();

// Doesn't block UI
final result = await Isolate.run(() => expensiveNativeOperation());
```

**4. Enable release mode optimizations:**
```toml
[profile.release]
opt-level = 3      # Maximum optimization
lto = true         # Link-time optimization
codegen-units = 1  # Single codegen unit for better optimization
```

## Debugging Tips

### Enable Rust logging

```rust
// In Cargo.toml
[dependencies]
log = "0.4"
env_logger = "0.11"

// In Rust code
#[no_mangle]
pub extern "C" fn init_logger() {
    let _ = env_logger::try_init();
}

fn some_function() {
    log::info!("Starting operation");
    log::debug!("Detailed info: {:?}", data);
    log::error!("Error occurred: {}", err);
}
```

```bash
# Run with logging enabled
RUST_LOG=debug dart run your_app.dart
```

### Enable Dart FFI debugging

```dart
import 'dart:developer' as developer;

void debugFFICall(String operation, Function() call) {
  developer.log('Starting: $operation');
  try {
    call();
    developer.log('Success: $operation');
  } catch (e) {
    developer.log('Error in $operation: $e');
    rethrow;
  }
}

// Usage:
debugFFICall('create handle', () {
  handle = createHandle(name);
});
```

### Check built library

```bash
# macOS/Linux: List exported symbols
nm -gU rust/target/release/libmy_bindings.dylib

# Windows: List exports
dumpbin /EXPORTS rust\target\release\my_bindings.dll

# Check library dependencies
# macOS
otool -L rust/target/release/libmy_bindings.dylib
# Linux
ldd rust/target/release/libmy_bindings.so
# Windows
Dependencies.exe rust\target\release\my_bindings.dll
```

### Verify asset loading

```dart
void verifyAsset() {
  try {
    // Try to call a simple function
    final result = nativeGetVersion();
    print('Successfully loaded native library, version: $result');
  } catch (e) {
    print('Failed to load native library: $e');
    print('Current directory: ${Directory.current.path}');
  }
}
```
