---
name: native-toolchain-rs
description: Build Rust-powered Dart/Flutter apps using native_toolchain_rs. Use this skill when setting up native_toolchain_rs projects, creating FFI bindings between Rust and Dart, implementing native functionality with Rust, debugging FFI issues, or migrating existing projects to use Native Assets. Also use when encountering errors related to Rust compilation, FFI memory management, or cross-platform builds.
---

# Native Toolchain Rs

## Overview

This skill provides comprehensive guidance for using **native_toolchain_rs**, a Dart package that automates Rust integration in Dart and Flutter projects through the Native Assets system. It eliminates manual build configuration by automatically handling cross-platform compilation, linking, and asset management.

Native_toolchain_rs is an opinionated, minimal-configuration solution that enforces FFI best practices and guides developers away from common mistakes. With just an `assetName` parameter and proper project structure, it handles building Rust code for multiple platforms automatically.

## When to Use This Skill

Use this skill when:
- Setting up a new native_toolchain_rs project from scratch
- Adding Rust functionality to an existing Dart/Flutter application
- Creating or fixing FFI bindings between Rust and Dart
- Implementing native features that need Rust's performance or ecosystem
- Debugging build failures, linking errors, or runtime crashes in FFI code
- Working with opaque handles, memory management, or resource cleanup
- Optimizing FFI performance or reducing memory usage
- Addressing platform-specific issues (iOS, Android, macOS, Windows, Linux)
- Migrating from manual Rust build scripts to Native Assets

## Quick Start Guide

### Prerequisites

Before starting, ensure you have:

1. **Rust toolchain** installed via [rustup](https://rustup.rs):
   ```bash
   curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
   ```

2. **Flutter on beta channel** (until Native Assets is stable):
   ```bash
   flutter channel beta
   flutter upgrade
   ```

3. **Platform-specific tools:**
   - **macOS/iOS:** Xcode Command Line Tools (`xcode-select --install`)
   - **Android:** Android NDK via Android Studio
   - **Windows:** Visual Studio with C++ development tools
   - **Linux:** Build essentials (`sudo apt-get install build-essential`)

### Basic Project Structure

A native_toolchain_rs project follows this structure:

```
your_project/
├── hook/
│   └── build.dart              # Native Assets build hook
├── lib/
│   └── src/
│       └── ffi/
│           ├── bindings.dart   # FFI function bindings
│           ├── native_types.dart
│           ├── ffi_utils.dart
│           └── finalizers.dart
├── rust/                       # Or "native/"
│   ├── Cargo.toml              # Rust package manifest
│   ├── rust-toolchain.toml     # Rust version lock
│   └── src/
│       └── lib.rs              # FFI entry point
└── pubspec.yaml
```

## Project Setup

### Step 1: Initialize Rust Workspace

Create the Rust project structure:

```bash
# Create rust directory
mkdir -p rust/src

# Create Cargo.toml
# See: assets/templates/Cargo.toml
```

Use the template in `assets/templates/Cargo.toml` as starting point. **Critical requirements:**

1. **Both crate types required:**
   ```toml
   [lib]
   crate-type = ["staticlib", "cdylib"]  # BOTH required!
   ```
   - `staticlib`: For iOS (static linking only)
   - `cdylib`: For all other platforms (dynamic linking)

2. **Package name becomes asset name:**
   ```toml
   [package]
   name = "my_bindings"  # This will be your assetName
   ```

### Step 2: Pin Rust Version

Create `rust/rust-toolchain.toml` (see `assets/templates/rust-toolchain.toml`):

**Critical: Use specific version, NOT "stable":**
```toml
[toolchain]
channel = "1.90.0"  # Specific version required
targets = [
  "aarch64-apple-darwin",
  "x86_64-apple-darwin",
  # ... list all target platforms
]
```

Install targets:
```bash
cd rust
rustup show  # Installs targets from rust-toolchain.toml
```

### Step 3: Configure pubspec.yaml

Add native_toolchain_rs to dev dependencies:

```yaml
dev_dependencies:
  hooks: ^0.20.4
  native_toolchain_rs:
    git:
      url: https://github.com/GregoryConrad/native_toolchain_rs
      ref: <commit-hash>
      path: native_toolchain_rs

# Add ffi dependency
dependencies:
  ffi: ^2.1.0
```

Run:
```bash
dart pub get
```

### Step 4: Create Build Hook

Create `hook/build.dart` (see `assets/templates/hook_build.dart`):

```dart
import 'package:hooks/hooks.dart';
import 'package:native_toolchain_rs/native_toolchain_rs.dart';

void main(List<String> args) async {
  await build(args, (input, output) async {
    await RustBuilder(
      assetName: 'my_bindings',  // Must match Cargo.toml name
    ).run(input: input, output: output);
  });
}
```

**Critical: assetName must match Cargo.toml package name exactly.**

### Step 5: Verify Setup

Test the build:
```bash
dart run --enable-experiment=native-assets
```

First build will be slow (compiling Rust for all platforms). Subsequent builds are incremental.

## Writing Rust FFI Code

### Core Principles

Follow these principles for safe FFI:

1. **Never panic across FFI boundary** - Always use `panic::catch_unwind`
2. **Return simple error codes** - Use integers (0 = success, negative = error)
3. **Store error details separately** - Use thread-local storage for messages
4. **Validate all inputs** - Check for null, validate types before use
5. **Use opaque handles** - Never expose complex types directly

### Basic FFI Function Template

See `assets/templates/rust_lib.rs` for complete examples. Every FFI function follows this pattern:

```rust
#[no_mangle]  // Prevent name mangling
pub extern "C" fn function_name(arg: *const c_char) -> i32 {
    // Step 1: Catch panics
    match panic::catch_unwind(|| {
        // Step 2: Validate inputs
        if arg.is_null() {
            set_last_error("Argument cannot be null");
            return -1;
        }

        // Step 3: Convert C types to Rust
        let rust_str = unsafe {
            match CStr::from_ptr(arg).to_str() {
                Ok(s) => s,
                Err(_) => {
                    set_last_error("Invalid UTF-8");
                    return -2;
                }
            }
        };

        // Step 4: Perform operation
        match perform_operation(rust_str) {
            Ok(_) => 0,
            Err(e) => {
                set_last_error(&e.to_string());
                -3
            }
        }
    }) {
        Ok(result) => result,
        Err(_) => {
            set_last_error("Panic occurred");
            -999
        }
    }
}
```

### Error Handling Pattern

Implement thread-local error storage (see `assets/templates/rust_lib.rs` for complete implementation):

```rust
thread_local! {
    static LAST_ERROR: RefCell<Option<String>> = RefCell::new(None);
}

pub fn set_last_error(error: &str) {
    LAST_ERROR.with(|e| *e.borrow_mut() = Some(error.to_string()));
}

#[no_mangle]
pub extern "C" fn get_last_error() -> *mut c_char {
    LAST_ERROR.with(|e| {
        match e.borrow_mut().take() {
            Some(err) => CString::new(err).unwrap().into_raw(),
            None => std::ptr::null_mut(),
        }
    })
}

#[no_mangle]
pub extern "C" fn free_error_string(ptr: *mut c_char) {
    if !ptr.is_null() {
        unsafe { drop(CString::from_raw(ptr)); }
    }
}
```

### Opaque Handle Pattern

For complex types that cross FFI boundary:

```rust
pub struct MyHandle {
    // Internal fields
    data: String,
    config: Config,
}

// Create: Transfer ownership to Dart
#[no_mangle]
pub extern "C" fn create_handle(name: *const c_char) -> *mut MyHandle {
    match panic::catch_unwind(|| {
        // Validate, create, return
        let handle = Box::new(MyHandle { /* ... */ });
        Box::into_raw(handle)  // Transfer ownership
    }) {
        Ok(result) => result,
        Err(_) => {
            set_last_error("Panic in create_handle");
            std::ptr::null_mut()
        }
    }
}

// Operate: Borrow from Dart
#[no_mangle]
pub extern "C" fn handle_operation(handle: *mut MyHandle) -> i32 {
    // Validate, borrow, operate, return code
}

// Destroy: Reclaim from Dart
#[no_mangle]
pub extern "C" fn destroy_handle(handle: *mut MyHandle) {
    if !handle.is_null() {
        unsafe { drop(Box::from_raw(handle)); }
    }
}
```

Complete examples in `assets/templates/rust_lib.rs`.

### Advanced Patterns

For detailed patterns, consult `references/ffi_patterns.md`:
- String return patterns
- Async operations with Tokio
- Callback patterns
- Database connections
- File processing

## Writing Dart Bindings

### Define Opaque Types

Create `lib/src/ffi/native_types.dart` (see `assets/templates/native_types.dart`):

```dart
import 'dart:ffi';

final class MyHandle extends Opaque {}
```

These represent native handles that Dart cannot directly access.

### Declare FFI Functions

Create `lib/src/ffi/bindings.dart` (see `assets/templates/dart_bindings.dart`):

```dart
import 'dart:ffi';
import 'package:ffi/ffi.dart';

const String _assetId = 'package:my_package/my_bindings';
//                              ^^^^^^^^^^  ^^^^^^^^^^^
//                              pubspec     Cargo.toml
//                              name        package name

@Native<Pointer<MyHandle> Function(Pointer<Utf8>)>(
  symbol: 'create_handle',  // Rust function name
  assetId: _assetId,
)
external Pointer<MyHandle> createHandle(Pointer<Utf8> name);

@Native<Void Function(Pointer<MyHandle>)>(
  symbol: 'destroy_handle',
  assetId: _assetId,
)
external void destroyHandle(Pointer<MyHandle> handle);

@Native<Int32 Function(Pointer<MyHandle>)>(
  symbol: 'handle_operation',
  assetId: _assetId,
)
external int handleOperation(Pointer<MyHandle> handle);
```

### Create Utility Functions

Create `lib/src/ffi/ffi_utils.dart` (see `assets/templates/ffi_utils.dart` for complete implementation):

```dart
Pointer<Utf8> stringToCString(String str) {
  return str.toNativeUtf8(allocator: malloc);
}

String cStringToDartString(Pointer<Utf8> ptr) {
  if (ptr == nullptr) throw ArgumentError.notNull('ptr');
  return ptr.toDartString();
}

void freeCString(Pointer<Utf8> ptr) {
  if (ptr != nullptr) malloc.free(ptr);
}

// Helper for automatic cleanup
T withCString<T>(String str, T Function(Pointer<Utf8>) callback) {
  final ptr = stringToCString(str);
  try {
    return callback(ptr);
  } finally {
    freeCString(ptr);
  }
}
```

### Build High-Level Wrapper

Wrap low-level FFI in safe, idiomatic Dart (see `assets/templates/dart_bindings.dart` for complete example):

```dart
class MyWrapper {
  final Pointer<MyHandle> _handle;

  MyWrapper(String name) : _handle = _createHandle(name) {
    // Attach finalizer for automatic cleanup
    _finalizer.attach(this, _handle, detach: this);
  }

  void dispose() {
    _finalizer.detach(this);  // Prevent double-free
    destroyHandle(_handle);
  }

  void performOperation() {
    final result = handleOperation(_handle);
    if (result != 0) {
      throw _getError() ?? 'Operation failed';
    }
  }

  static Pointer<MyHandle> _createHandle(String name) {
    final namePtr = stringToCString(name);
    try {
      final handle = createHandle(namePtr);
      if (handle == nullptr) {
        throw _getError() ?? 'Failed to create handle';
      }
      return handle;
    } finally {
      freeCString(namePtr);
    }
  }

  static String? _getError() {
    final errorPtr = getLastError();
    if (errorPtr == nullptr) return null;
    try {
      return cStringToDartString(errorPtr);
    } finally {
      freeErrorString(errorPtr);
    }
  }

  static final _finalizer = NativeFinalizer(
    Native.addressOf<Void Function(Pointer<MyHandle>)>(destroyHandle),
  );
}
```

**Benefits of wrapper:**
- Users never see `Pointer` types
- Automatic memory management via finalizers
- Idiomatic async/await support
- Exception-based error handling

## Building and Testing

### Development Build

```bash
# Dart project
dart run --enable-experiment=native-assets

# Flutter project
flutter run --enable-experiment=native-assets
```

### Clean Build

If encountering stale build issues:

```bash
# Clean Dart artifacts
dart clean

# Clean Rust artifacts
cd rust && cargo clean && cd ..

# Rebuild
dart run --enable-experiment=native-assets
```

### Testing

Test Rust and Dart independently:

**Rust tests:**
```bash
cd rust
cargo test
```

**Dart tests:**
```dart
import 'package:test/test.dart';

void main() {
  test('FFI integration', () {
    final wrapper = MyWrapper('test');
    expect(() => wrapper.performOperation(), returnsNormally);
    wrapper.dispose();
  });
}
```

```bash
dart test --enable-experiment=native-assets
```

### Platform-Specific Builds

**iOS:**
```bash
flutter build ios --enable-experiment=native-assets
```

**Android:**
```bash
flutter build apk --enable-experiment=native-assets
```

**Verify Android library inclusion:**
```bash
unzip -l build/app/outputs/flutter-apk/app-release.apk | grep "\.so"
```

### Debugging

**Enable Rust logging:**
```rust
// Add to Cargo.toml
[dependencies]
log = "0.4"
env_logger = "0.11"

// Initialize in Rust
#[no_mangle]
pub extern "C" fn init_logger() {
    let _ = env_logger::try_init();
}

// Use in functions
log::info!("Operation started");
log::error!("Error: {}", err);
```

```bash
RUST_LOG=debug dart run --enable-experiment=native-assets
```

**Check exported symbols:**
```bash
# macOS/Linux
nm -gU rust/target/release/libmy_bindings.dylib | grep my_function

# Windows
dumpbin /EXPORTS rust\target\release\my_bindings.dll | findstr my_function
```

## Troubleshooting

### Common Build Errors

**"error: can't find crate for `std`"**
→ Missing Rust target. Install with: `rustup target add <target-name>`

**"error: invalid channel name: 'stable'"**
→ Use specific version in rust-toolchain.toml: `channel = "1.90.0"`

**"crate-type must include both staticlib and cdylib"**
→ Add both to Cargo.toml: `crate-type = ["staticlib", "cdylib"]`

**"Asset not found: package:my_package/my_asset"**
→ Ensure consistency:
- Cargo.toml `name = "my_asset"`
- hook/build.dart `assetName: 'my_asset'`
- Dart bindings `assetId: 'package:my_package/my_asset'`

### Common Runtime Errors

**"Symbol not found"**
→ Check `#[no_mangle]` and `extern "C"` on Rust functions

**Segmentation fault**
→ Common causes:
- Null pointer dereference (add null checks)
- Use-after-free (ensure proper lifetime management)
- Double-free (use `detach()` before manual `dispose()`)
- Buffer overflow (validate buffer sizes)

**Memory leaks**
→ Common causes:
- Not freeing strings (always use try-finally)
- Not destroying handles (use finalizers)
- Missing destructor calls

For detailed troubleshooting, see `references/troubleshooting.md`.

### Platform-Specific Issues

**iOS: "Building for iOS, but the linked library is for macOS"**
→ Add iOS targets to rust-toolchain.toml

**Android: "No implementation found for nativeMethod"**
→ Verify Android NDK is installed and targets are correct

**Windows: "The specified module could not be found"**
→ Install Visual C++ Redistributables

For comprehensive platform guidance, see `references/platform_considerations.md`.

## Best Practices

### Memory Management

1. **Always pair create/destroy:**
   ```dart
   final handle = createHandle();
   try {
     useHandle(handle);
   } finally {
     destroyHandle(handle);
   }
   ```

2. **Use finalizers for automatic cleanup:**
   ```dart
   class Wrapper {
     Wrapper() {
       _finalizer.attach(this, _handle, detach: this);
     }
     void dispose() {
       _finalizer.detach(this);
       destroyHandle(_handle);
     }
   }
   ```

3. **Free all allocated strings:**
   ```dart
   final ptr = stringToCString('text');
   try {
     nativeFunction(ptr);
   } finally {
     freeCString(ptr);
   }
   ```

### Performance Optimization

1. **Batch operations:**
   ```dart
   // Slow: 1000 FFI calls
   for (var item in items) {
     nativeProcess(item);
   }

   // Fast: 1 FFI call
   final batch = items.join(',');
   nativeProcessBatch(batch);
   ```

2. **Reuse allocations:**
   ```dart
   // Slow: Allocate on every call
   for (var i = 0; i < 1000; i++) {
     final ptr = stringToCString('constant');
     nativeCall(ptr);
     freeCString(ptr);
   }

   // Fast: Allocate once
   final ptr = stringToCString('constant');
   try {
     for (var i = 0; i < 1000; i++) {
       nativeCall(ptr);
     }
   } finally {
     freeCString(ptr);
   }
   ```

3. **Use Isolates for heavy work:**
   ```dart
   // Doesn't block UI
   final result = await Isolate.run(() => expensiveOperation());
   ```

### Error Handling

1. **Always check error codes:**
   ```dart
   final result = nativeOperation(handle);
   if (result != 0) {
     final error = getLastError();
     throw Exception('Operation failed: $error');
   }
   ```

2. **Define error code conventions:**
   - `0` = Success
   - `-1` = Invalid input
   - `-2` = Conversion error
   - `-3 to -99` = Domain-specific errors
   - `-999` = Panic occurred

## Resources

This skill includes comprehensive resources to accelerate development:

### assets/templates/

Ready-to-use template files for quick project setup:

- **Cargo.toml** - Rust package manifest with proper crate types and dependencies
- **rust-toolchain.toml** - Rust version pinning with multi-platform targets
- **hook_build.dart** - Native Assets build hook configuration
- **rust_lib.rs** - Complete Rust FFI example with error handling and handles
- **dart_bindings.dart** - Dart FFI bindings with @Native annotations
- **native_types.dart** - Opaque type definitions
- **ffi_utils.dart** - Safe utility functions for string conversion and memory management

Copy these templates to your project and customize the placeholders ({{PACKAGE_NAME}}, {{ASSET_NAME}}, etc.).

### references/

Detailed documentation loaded as needed:

- **ffi_patterns.md** - Comprehensive FFI patterns and best practices
  - Error handling patterns
  - Memory management patterns
  - String handling
  - Async operations
  - Callback patterns
  - Platform-specific patterns

- **troubleshooting.md** - Common issues and solutions
  - Build errors and fixes
  - Runtime errors (segfaults, memory leaks)
  - Configuration issues
  - Platform-specific problems
  - Debugging techniques

- **platform_considerations.md** - Platform-specific details
  - Target architectures for each platform
  - Platform requirements and dependencies
  - iOS static linking requirements
  - Android NDK configuration
  - Windows MSVC setup
  - Cross-compilation tips

Read these references when encountering specific issues or implementing advanced features.

## Additional Notes

### Asset Name Consistency

The most common source of errors is inconsistency between asset names. Always ensure:

1. **Cargo.toml:**
   ```toml
   [package]
   name = "my_bindings"
   ```

2. **hook/build.dart:**
   ```dart
   RustBuilder(assetName: 'my_bindings')
   ```

3. **Dart bindings:**
   ```dart
   const _assetId = 'package:my_package/my_bindings';
   ```

All three must match exactly.

### Web Platform

Native_toolchain_rs does not support web targets. For web compatibility:
- Compile Rust to WASM separately using wasm-pack
- Provide pure Dart fallback implementations
- Use conditional compilation based on `kIsWeb`

### CI/CD Integration

Example GitHub Actions workflow for multi-platform builds:

```yaml
jobs:
  build:
    strategy:
      matrix:
        os: [ubuntu-latest, macos-latest, windows-latest]
    runs-on: ${{ matrix.os }}
    steps:
      - uses: actions/checkout@v3
      - uses: actions-rs/toolchain@v1
        with:
          toolchain: 1.90.0
      - uses: dart-lang/setup-dart@v1
      - run: rustup show
      - run: dart pub get
      - run: dart run --enable-experiment=native-assets
      - run: dart test --enable-experiment=native-assets
```

### Migration from Manual Builds

If migrating from manual Rust build scripts:

1. Remove manual build scripts and commands
2. Set up native_toolchain_rs project structure
3. Create hook/build.dart with RustBuilder
4. Update imports to use @Native annotation
5. Clean all build artifacts
6. Test on all target platforms

The Native Assets system handles everything automatically.
